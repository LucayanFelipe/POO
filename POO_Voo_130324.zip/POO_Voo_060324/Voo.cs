﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_Voo
{
    internal class Voo
    {
        private DateTime dataHora;
        private int numMaxVagas;
        private int numVoo;
        private bool [] vagas;

        public Voo(int numVoo, DateTime dataHora, int numMaxVagas)
        {
            this.numVoo = numVoo;
            this.dataHora = dataHora;
            this.numMaxVagas = numMaxVagas; 
            vagas = new bool[numMaxVagas];
            
            //deixa todas as vagas disponiveis
            for (int i=0;i<numMaxVagas; i++)
            {
                vagas[i] = false;
            }
        }

        public void printarVoo()
        {
            Console.WriteLine("POLTRONAS: (O) disponivel (X) indisponivel\n");       
            for (int i =0;i<numMaxVagas;i++)
            {
                if (vagas[i]==false) Console.Write($"{i+1}: O\t");
                if (vagas[i]==true) Console.Write($"{i+1}: X\t");
                if (i % 9 == 0 && i != 0) { Console.WriteLine();}
            }
            Console.WriteLine(
               $"\n|numero do voo: {getVoo()}|\n" +
               $"|data do voo: {getData()}|\n");
            Console.WriteLine();
        }

        public bool ocupa (int pos)
        {
            if (pos > 0)
            {
                pos--;
                //ocupa a vaga na posição especificada
                if (vagas[pos] == false)
                {
                    vagas[pos] = true;
                    Console.WriteLine($"Cadeira {pos+1} ocupada com sucesso!");
                    Console.ReadKey();
                    return true;
                }
                else
                {
                    Console.WriteLine($"Cadeira {pos+1} indisponivel!");
                    Console.ReadKey();
                    return false;
                }
            } 
            else
            {
                Console.WriteLine($"Cadeira {pos+1} indisponivel!");
                Console.ReadKey();
                return false;
            }
        }

        public int vagasDisponiveis()
        {
            int disponivel = 0;
            //verifica quais estão disponiveis
            for(int i=0;i<numMaxVagas;i++)
            {
                if (vagas[i] == false)
                {
                    disponivel++;
                }
            
            }
            return disponivel;
        }

        public void ShowVagasDisponiveis()
        {
            int disponivel = 0;
            //verifica quais estão disponiveis
            Console.WriteLine();
            for (int i = 0; i < numMaxVagas; i++)
            {
                if (vagas[i] == false)
                {
                    Console.WriteLine($"cadeira {i+1} disponivel!");
                }
            }
        }

        public void ShowVagasOcupadas()
        {
            int disponivel = 0;
            Console.WriteLine();
            for (int i = 0; i < numMaxVagas; i++)
            {
                if (vagas[i] == false) disponivel++;
                if (vagas[i] == true)
                {
                    Console.WriteLine($"cadeira {i + 1} ocupada!");
                }
            }
        }

        public bool verificaOcupado(int pos)
        {
            pos--;
                if (vagas[pos] == false)
                {
                    return false;
                }
                else
            {
                return true;
            }
        }

        public int ProximoLivre()
        {
            for(int i=0;i<numMaxVagas;i++)
            {
                if (vagas[i]==false)
                {
                    Console.WriteLine($"cadeira {i+1} disponivel!");
                    return i+1;
                }
            }
            return 0;
        }

        public int getVoo ()
        {
            return numVoo;
        }
        public DateTime getData ()
        {
            return dataHora;
        }
        
        

    }
}
