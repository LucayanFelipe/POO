﻿using System.ComponentModel.Design;

namespace POO_Voo
{
    internal class Program
    {

        public static void ex1()
        {
            Voo v1 = new Voo(1, DateTime.Now, 100);
            Voo v2 = new Voo(2, DateTime.Now, 50);
            v1.ocupa(1);
            v1.ocupa(2);
            v1.printarVoo();

            Console.WriteLine("disponiveis: "+ v1.vagasDisponiveis() + "\n");

            v1.ProximoLivre();

            Console.ReadKey();
        }



        public static void menuConsulta(List<Voo> Voos, int numVoo)
        {
            int vaga = 0;
            string menu = "";
            numVoo--;
            do
            {
                Console.Clear();
                Voos[numVoo].printarVoo();
                Console.WriteLine("Digite o que deseja fazer!\n" +
                    "1: Ocupar uma vaga\n2: Consultas cadeira disponivel\n3: voltar");
                menu = Console.ReadLine();
                switch(menu)
                {
                    case "1":
                        Console.Clear();
                        Voos[numVoo].printarVoo();
                        Console.WriteLine("Digite qual vaga deseja ocupar!");
                        vaga = Convert.ToInt32(Console.ReadLine());
                        Voos[numVoo].ocupa(vaga);
                        break;

                    case "2":
                        Console.Clear();
                        Voos[numVoo].printarVoo();
                        Voos[numVoo].ProximoLivre();
                        Console.ReadKey();
                        break;

                }


            } while (menu != "3");
        }
        public static void menuVoo ()
        {
            string menu = "";
            int vagas = 0;
            int numVoo = 0;
            List<Voo> Voos = new List<Voo>();

            do
            {
                Console.Clear();
                Console.WriteLine("Bem vindo ao voo intergaláctico filho de uma puta\n" +
                    "1: Cadastrar novo Voo\n2: Consultar Voos disponivel");
                menu = Console.ReadLine();
                switch(menu)
                {
                    case "1":
                        Console.Clear();
                        Console.WriteLine("Vamos cadastrar um novo voo!\n" +
                            "Digite quantas vagas seu voo terá!");
                        vagas = Convert.ToInt32(Console.ReadLine());
                        Voo v = new Voo(++numVoo,DateTime.Now,vagas);
                        Voos.Add(v);
                        Console.Clear();
                        Console.WriteLine($"\nVoo nº{numVoo} CADASTRADO! consulte-o agora!");
                        Console.ReadKey();
                        break;
                    case "2":
                        Console.Clear();
                        for(int i = 0;i<Voos.Count;i++)
                        {
                            Console.WriteLine($"Voo nº{i+1} - Vagas disponiveis {Voos[i].vagasDisponiveis()}");
                        }
                        Console.WriteLine("\nDigite qual voo deseja consultar!");
                        int numVooTemp = Convert.ToInt32(Console.ReadLine());
                        menuConsulta(Voos,numVooTemp);
                        break;
                }



            } while (menu!="stop");

        }

        static void Main(string[] args)
        {
            menuVoo();

        }
    }
}
