﻿using Gerenciamento_veiculo_multa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal static class Validacoes
    {

        //025.147.052-07
        //10 9 8

        public static bool validaCpfProfessor(string cpf)
        {
            cpf = cpf.Replace(".", "").Replace("-","");
            int soma = 0, prid=0, segd=0;

            //verifica o tamanho do cpf
            if (cpf.Length!=11)
            {
                return false;
            }

            //percorre e soma até o decimo digimo
            for (int i = 0; i < cpf.Length - 2; i++)
            {
                soma += Convert.ToInt32(cpf[i].ToString()) * (10 - i);
            }

            //verificação do primeiro digito
            prid = soma % 11;
            if (prid < 2) prid = 0;
            else prid = 11 - prid;
            int teste = Convert.ToInt32(cpf[9].ToString());
            if (prid != teste) return false;

            //zera soma
            soma = 0;

            //percorre e soma até o decimo primeiro digito
            for(int i=0; i< cpf.Length -1; i++)
            {
                soma += Convert.ToInt32(cpf[i].ToString()) * (11 - i);
            }
            //verificação do segundo digito
            segd = soma % 11;
            if (segd < 2) segd = 0;
            else segd = 11 - segd;
            if (segd != Convert.ToInt32(cpf[10].ToString())) return false;

            return true;
        }

        public static bool validaCpf(string cpf)
        {
            int verify, verify2;
            int digit = 0;
            int letter = 0;
            int somaCpf = 0;
            int restoCpf = 0;
            bool dig1 = false, dig2 = false;

            cpf = cpf.Replace(".", "");
            cpf = cpf.Replace("-", "");

            if (cpf.Length != 11) return false;
            else 
            {
                for (int i = 0; i < cpf.Length - 2; i++)
                {
                    somaCpf += Convert.ToInt32(cpf[i].ToString()) * 10-i;
                }
                restoCpf = somaCpf % 11;

                //teste do digito 1
                if (restoCpf < 2)
                {
                    if (cpf[9] == '0') dig1 = true;
                }
                else
                {
                    verify = 11 - restoCpf;
                    if (cpf[9].ToString() == verify.ToString()) dig1 = true;
                }

                //teste do digito 2
                //052.654.852-64
                if (dig1 = true)
                {
                    somaCpf = 0;
                    for (int i = 0; i < cpf.Length - 1; i++)
                    {
                        somaCpf += Convert.ToInt32(cpf[i].ToString()) * (11-i);
                    }
                    restoCpf = somaCpf % 11;
                    if (restoCpf < 2)
                    {
                        if (cpf[10] == '0') dig2 = true;
                    }
                    else
                    {
                        verify2 = 11 - restoCpf;
                        if (cpf[10].ToString() == verify2.ToString()) dig2 = true;
                    }
                }

            }
           

            if (dig1 && dig2) return true;        
            else return false;
        }

        public static bool validaChassi(string chassi)
        {
            chassi = chassi.ToUpper();
            chassi = chassi.Replace(" ", "");

            if (chassi.Length != 17) return false;

            if (chassi.Contains("O") || chassi.Contains("I") || chassi.Contains("Q")) return false;

            if (char.IsDigit(chassi[16]) && char.IsDigit(chassi[15]) && char.IsDigit(chassi[14]) && char.IsDigit(chassi[13])) return true;

            return false;
        }

    }
}


/*
 questao 9:
ache o erro!
vou colocar um membro nao estatico em uma classe static!
facinho

criar um atributo estatico e chamar como objeto
tipo: 
class Alunos {
public static string media
}

program {
Alunos a1 = new Alunos();
a1.media = "234"; <- VAI DAR ERRO BURRO!

Alunos.media = "234"; <- agora ta certo filho!
}
 */

/*
Modelo conceitual
mapeamento do conceito
    like 
    max min
    sum
*/

/*
questao 8
validar cpf
boa sorte filho de uma puta esse ai vai ser foda
*/