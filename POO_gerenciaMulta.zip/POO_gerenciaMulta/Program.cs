﻿using System.Runtime.CompilerServices;

namespace Gerenciamento_veiculo_multa
{
    internal class Program
    {
        static List<ProprietarioPF> listaPF = new List<ProprietarioPF>();

        public static void cadastrarPF()
        {
            string sexoNovo = "";
            bool dateFormat = true;

            ProprietarioPF novo = new ProprietarioPF();
            Console.WriteLine("Informe seu nome: ");
            novo.nome = Console.ReadLine();

            Console.Clear();
            //Verificar cpf valido
            Console.WriteLine("Informe seu cpf: ");
            novo.setCpf(Console.ReadLine());
            do
            {
                if (!Validacoes.validaCpf(novo.getCpf())) 
                {
                    Console.Clear();
                    Console.WriteLine("CPF INVALIDO! ");
                    Console.ReadKey();
                    Console.Clear();
                    Console.WriteLine("Informe seu cpf: ");
                    novo.setCpf(Console.ReadLine());
                }
            } while (!Validacoes.validaCpf(novo.getCpf()));
            //end verificar cpf

            Console.Clear();
            Console.WriteLine("informe seu rg: ");
            novo.rg = Console.ReadLine();

            //verificar formato da data
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("informe sua data de nascimento no formato  DD/MM/YYYY");
                    novo.data_nascimento = DateOnly.Parse(Console.ReadLine());
                    dateFormat = false;
                } catch (Exception ex)
                {
                    Console.Clear();
                    Console.WriteLine("Formato incorreto, tente novamente!");
                    Console.ReadKey();
                }
            } while (dateFormat);
            //end verificar formato da data

            

            do
            {
                Console.Clear();
                Console.WriteLine("Selecione um sexo valido!\n" +
                    "0: masculino\n" +
                    "1: feminino\n" +
                    "2: outros");
                sexoNovo = Console.ReadLine();
                novo.setSexo(Convert.ToInt32(sexoNovo)); 
            }  while (sexoNovo!="0" && sexoNovo!="1" && sexoNovo!="2");


            listaPF.Add(novo);
            

        

        }

        public static void menuProprietario()
        {
            string menu = "";
            do
            {
                Console.Clear();
                Console.WriteLine("\t\t\t\tCADASTRAR PROPRETÁRIO\n" +
                    "\t\t\t\t selecione uma opção\n\n" +
                    "\t\t\t1: Cadastrar Proprietario Pessoa Física\n" +
                    "\t\t\t2: Cadastrar Proprietario Pessoa Juridica\n" +
                    "\t\t\t3: voltar");
                menu = Console.ReadLine();

                switch (menu)
                {
                    case "1":
                        Console.Clear();
                        cadastrarPF();

                        break;
                    case "2":
                        
                        break;
                    case "3":
                        break;
                    default:
                        Console.WriteLine("Opção invalida!");
                        Console.ReadKey();
                        break;
                }
            } while (menu!="3");
        }

        public static void menuCadastro()
        {
            string menu = "";
            do
            {
                Console.Clear();
                Console.WriteLine("\t\t\t\t   MENU CADASTRO\n" +
                    "\t\t\t\tselecione uma opção\n\n" +
                    "\t\t\t1: Cadastrar Proprietario\n" +
                    "\t\t\t2: Cadastrar Veiculo\n" +
                    "\t\t\t3: voltar");
                menu = Console.ReadLine();

                switch (menu)
                {
                    case "1":
                        menuProprietario();
                        break;
                    case "3":
                        break;
                    default:
                        Console.WriteLine("Opção invalida!");
                        Console.ReadKey();
                        break;
                }
            } while (menu != "3");
        }

        public static void menuConsulta()
        {
            string menu = "";
            do
            {
                Console.Clear();
                Console.WriteLine("\t\t\t\tMENU DE CONSULTAS\n" +
                    "\t\t\t\tselecione uma opção\n\n" +
                    "\t\t\t1: Consultar Proprietarios\n" +
                    "\t\t\t2: Consultar Veiculos\n" +
                    "\t\t\t3: voltar");
                menu = Console.ReadLine();

                switch (menu)
                {
                    case "1":
                        Console.Clear();
                        for(int i=0;i<listaPF.Count;i++)
                        {
                            Console.WriteLine(
                                $"-----------------x--------------x---------------x-----------------\n" +
                                $"\t\tnome: {listaPF[i].nome}\n" +
                                $"\t\tcpf: {listaPF[i].getCpf()}\n" +
                                $"\t\trg: {listaPF[i].rg}\n" +
                                $"\t\tdata de nascimento: {listaPF[i].data_nascimento}\n" +
                                $"\t\tsexo: {listaPF[i].sex}\n" +
                                $"-----------------x--------------x---------------x-----------------\n");
                        }
                        Console.ReadKey();
                        break;

                    case "2":
                        
                        break;

                    case "3":
                        break;
                    default:
                        Console.WriteLine("Opção invalida!");
                        Console.ReadKey();
                        break;
                }
            } while (menu != "3");
        }

        static void Main(string[] args)
        {
            Console.WriteLine(Validacoes.validaChassi("67J b89HAg gc Cx01C0"));
            

            /*string menu = "";
            do
            {
                Console.Clear();
                Console.WriteLine("\t\t\t-- | GERENCIAMENTO DE VEICULOS E MULTAS | --\n" +
                    "\t\t\t\t- | selecione uma opção | -\n\n" +
                    "\t\t\t1: Menu de Cadastro\n" +
                    "\t\t\t2: Menu de Consulta\n" +
                    "\t\t\t3: sair");
                menu = Console.ReadLine();

                switch(menu)
                {
                    case "1":
                        menuCadastro();
                        break;

                    case "2":
                        menuConsulta();
                        break;

                    case "3":
                        Console.Clear();
                        break;
                    default:
                        Console.WriteLine("Opção invalida!");
                        Console.ReadKey();
                        break;
                }
            } while (menu != "3");


            */
        }
    }
}
