﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Aplicacao_multa
    {
        public int id_apMulta;
        public DateOnly data;
        public TimeOnly horario;
        public string longitude;
        public string latitude;
        public decimal valor_aplicado;
        public Multa multa;
        public Veiculo veiculoMultaAplicada;
        public ProprietarioPF proprietarioPF_multa;
    }
}
