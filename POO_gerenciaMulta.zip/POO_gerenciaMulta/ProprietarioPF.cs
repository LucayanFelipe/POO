﻿namespace Gerenciamento_veiculo_multa
{
    internal class ProprietarioPF:Proprietario
    {
        public int id_proprietarioPF;
        public string nome;
        private string cpf;
        public string rg;
        public DateOnly data_nascimento;
        public enum Sexo {
            masculino,
            feminino,
            outros
        }

        public Sexo sex;

        public void setCpf (string cpf)
        {
            this.cpf = cpf;
        } 
        public string getCpf ()
        {
            return cpf;
        }

        public void setSexo (int sexo)
        {
            if (sexo == 0) sex = Sexo.masculino;
            if (sexo == 1) sex = Sexo.feminino;
            if (sexo == 2) sex = Sexo.outros;
        }

    }
}
