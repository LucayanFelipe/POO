﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Endereco
    {
        public int id_endereco;
        public string cep;
        public string logradouro;
        public string bairro;
        public string numero;
        public Cidade cidadeEndereco;
    }
}
