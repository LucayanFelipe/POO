﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Multa
    {
        public int id_multa;
        public string descricao;
        public enum tipo
        {
            leve,
            media,
            grave,
            gravissima
        }
        public decimal valor_atual;
        public int penalidade_pontos;
        public string fator;
    }
}
