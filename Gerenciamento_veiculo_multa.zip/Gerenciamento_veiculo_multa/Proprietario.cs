﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Proprietario
    {
        public int id_proprietario;
        public string email;
        public string telefone;
        public Endereco enderecoProprietario;
    }
}
