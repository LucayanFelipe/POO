﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Cidade
    {
        public int id_cidade;
        public string nome;
        public string codigo_ibge;
        public Estado estadoCidade;
    }
}
