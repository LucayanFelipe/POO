﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Marca
    {
        public int id_marca;
        public string nome;
        public string observacao;
        public string localidade;
    }
}
