﻿using Gerenciamento_veiculo_multa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal static class Validacoes
    {

        //025.147.052-07
        //10 9 8
        public static bool validaCpf(string cpf)
        {
            int verify, verify2;
            int digit = 0;
            int letter = 0;
            int somaCpf = 0;
            int restoCpf = 0;
            bool dig1=false,dig2=false;

            cpf = cpf.Replace(".", "");
            cpf = cpf.Replace("-", "");

            for (int i = 0; i < cpf.Length; i++)
            {
                if (char.IsDigit(cpf[i])) digit++;
                if (char.IsLetter(cpf[i])) letter++;
            }

            if(digit == 11)
            {
                for (int i = 0, x=10; i < cpf.Length-2; i++, x--)
                {   
                    somaCpf += Convert.ToInt32(cpf[i].ToString()) * x;
                }
                restoCpf = somaCpf % 11;

                //teste do digito 1
                if(restoCpf < 2)
                {
                    if (cpf[9] == '0') dig1 = true; 
                }  else
                {
                    verify = 11 - restoCpf;
                    if (cpf[9] == verify) dig1 = true;
                }

                //teste do digito 2
                //052.654.852-64
                if (dig1 =true)
                {
                    somaCpf = 0;
                    for (int i = 0, x = 11; i < cpf.Length - 1; i++, x--)
                    {
                        somaCpf += Convert.ToInt32(cpf[i].ToString()) * x;
                    }
                    restoCpf = somaCpf % 11;
                    if (restoCpf < 2)
                    {
                        if (cpf[10] == '0') dig2 = true;
                    } else
                    {
                        verify2 = 11 - restoCpf;
                        if (cpf[10] == verify2) dig2 = true;
                    }
                }


            }   


          
                
            

            if (letter > 0) return false;
            if (digit == 11 && dig1 && dig2) return true;        
            else return false;
        }

    }
}


/*
 questao 9:
ache o erro!
vou colocar um membro nao estatico em uma classe static!
facinho

criar um atributo estatico e chamar como objeto
tipo: 
class Alunos {
public static string media
}

program {
Alunos a1 = new Alunos();
a1.media = "234"; <- VAI DAR ERRO BURRO!

Alunos.media = "234"; <- agora ta certo filho!
}
 */

/*
Modelo conceitual
mapeamento do conceito
    like 
    max min
    sum
*/