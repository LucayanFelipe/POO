﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Estado
    {
        public int id_estado;
        public string nome;
        public string sigla;
        public string nome_pais;
    }
}
