﻿

namespace Gerenciamento_veiculo_multa
{
    internal class ProprietarioPJ:Proprietario
    {
        public int id_proprietarioPJ;
        public string cnpj;
        public string razao_social;
        public string nome_fantasia;
        public enum situacao
        {
            ativa,
            inativa
        }
        public string atividade_economica;
        public string inscricao_estadual;
    }
}
