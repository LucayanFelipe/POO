﻿namespace Gerenciamento_veiculo_multa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ProprietarioPF p1 = new ProprietarioPF();
            p1.setCpf("025.147.052.07");
            
            Console.WriteLine(Validacoes.validaCpf(p1.getCpf()));

            Console.ReadKey();
        }
    }
}
