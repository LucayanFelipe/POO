﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Modelo
    {
        public int id_modelo;
        public string descricao;
        public int qtd_eixos;
        public double peso;
        public int qtd_passageiros;
        public int cavalaria;
        public float cilindradas;
        public Marca marcaModelo;
    }
}
