﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Veiculo
    {
        public int id_veiculo;
        private string chassis;
        public string numero_placa;
        public string numero_motor;
        public string renavam;
        public string ano_modelo;
        

        public enum situacao
        {
            em_circulacao,
            apreendido,
            baixa
        }
        public string cor;
        public Cidade cidadeVeiculo;
        public Proprietario proprietarioVeiculo;
        public Modelo modeloVeiculo;

        public Veiculo (Proprietario proprietarioVeiculo, Cidade cidadeVeiculo, Modelo modeloVeiculo)
        {
            this.proprietarioVeiculo = proprietarioVeiculo;
            this.cidadeVeiculo = cidadeVeiculo;
            this.modeloVeiculo = modeloVeiculo;
        }

        public Veiculo ()
        {

        }

        public void setChassis (string num)
        {
            chassis = num;
        }

        public string getChassis()
        {
            return chassis;
        }

    }
}
