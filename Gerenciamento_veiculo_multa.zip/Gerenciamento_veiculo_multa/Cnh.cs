﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciamento_veiculo_multa
{
    internal class Cnh
    {
        public int id_cnh;
        public DateOnly data_emissao;
        public DateOnly data_vencimento;
        public string categoria;
        public int pontuacao;
        public string numero;
        public ProprietarioPF proprietarioPF_cnh;
    }
}
