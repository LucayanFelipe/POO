﻿namespace Gerenciamento_veiculo_multa
{
    internal class ProprietarioPF:Proprietario
    {
        public int id_proprietarioPF;
        public string nome;
        private string cpf;
        public string rg;
        public DateOnly data_nascimento;
        public enum sexo {
            masculino,
            feminino,
            outro
        }

        public void setCpf (string cpf)
        {
            this.cpf = cpf;
        } 
        public string getCpf ()
        {
            return cpf;
        }
    }
}
